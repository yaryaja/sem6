import torch
# import modules
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import matplotlib.pyplot as plt
import numpy as np
import nltk
from nltk.tokenize import word_tokenize
import string
nltk.download('punkt')  # Make sure you have the punkt tokenizer data downloaded
import csv
import re
import random
import copy
from gensim.models import KeyedVectors
import numpy as np
import random





## device 
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')



### define the Elmo class
class ELMO(nn.Module):

    def __init__(self, embedding_matrix, hidden_dim, vocab_size, mode, length ):
        super(ELMO, self).__init__()

        self.hidden_dim = hidden_dim

        # Embedding layer with pretrained embeddings
        self.embedding = nn.Embedding.from_pretrained(embedding_matrix)

        # First LSTM layer
        self.lstm1_forward = nn.LSTM(input_size=embedding_matrix.shape[1], hidden_size=hidden_dim, batch_first=True)

        # Second LSTM layer
        self.lstm2_forward = nn.LSTM(input_size=hidden_dim, hidden_size=hidden_dim, batch_first=True)
        
        self.output_layer_front = nn.Linear(hidden_dim, vocab_size)

        # backward model 
        
        # Output layer with output dimension vocab_size
        
        self.lstm1_back = nn.LSTM(input_size=embedding_matrix.shape[1], hidden_size=hidden_dim, batch_first=True)

        # Second LSTM layer
        self.lstm2_back = nn.LSTM(input_size=hidden_dim, hidden_size=hidden_dim, batch_first=True)

        # Output layer with output dimension vocab_size
        self.output_layer_back = nn.Linear(hidden_dim, vocab_size)
        
        
#         ELMO
        weight_value = 0.33
        self.weight1 = nn.Parameter(torch.tensor([weight_value], requires_grad=True))
        self.weight2 = nn.Parameter(torch.tensor([weight_value], requires_grad=True))
        self.weight3 = nn.Parameter(torch.tensor([weight_value], requires_grad=True))
        
        
        ### Learnable Function
        self.output_= nn.Linear(50*600 , 4)

    def forward(self,  input_indices, mode):
        embedded_sequence = self.embedding(input_indices)
        embedded_sequence = embedded_sequence.to(self.lstm1_forward.weight_ih_l0.dtype)

        

        if mode == 3:
            # Freeze parameters of the LSTM layers
            for param in self.lstm1_forward.parameters():
                param.requires_grad = False
            for param in self.lstm2_forward.parameters():
                param.requires_grad = False
            for param in self.lstm1_back.parameters():
                param.requires_grad = False
            for param in self.lstm2_back.parameters():
                param.requires_grad = False
                
            # ELMO prediction
            lstm1_output_f , _ = self.lstm1_forward(embedded_sequence)
            lstm2_output_f , _ = self.lstm2_forward(lstm1_output_f)
            embedded_sequencer= torch.flip(embedded_sequence, [1])
            lstm1_output_r , _= self.lstm1_back(embedded_sequence)
            lstm2_output_r , _ = self.lstm2_back(lstm1_output_r)
            lstm1_output_combined = torch.cat([lstm1_output_f, lstm1_output_r], dim=1)
            lstm2_output_combined = torch.cat([lstm2_output_f, lstm2_output_r], dim=1)
            embed_output_combined = torch.cat([embedded_sequencer,embedded_sequence], dim=1)
            
            
            # Combine LSTM outputs with trainable weights
            weights = torch.softmax(torch.cat([self.weight1, self.weight2, self.weight3]), dim=0)
            weighted_sum = weights[0] * lstm1_output_combined + weights[1] * lstm2_output_combined + weights[2] * embed_output_combined
#             print(len(weighted_sum[0][0]))
#             print("entered")
#             print(weighted_sum.shape)
            weighted_sum = weighted_sum.view(-1)
            output_probs = self.output_(weighted_sum)
        elif mode==4:
             # Freeze parameters of the LSTM layers 
            for param in self.lstm1_forward.parameters():
                param.requires_grad = False
            for param in self.lstm2_forward.parameters():
                param.requires_grad = False
            for param in self.lstm1_back.parameters():
                param.requires_grad = False
            for param in self.lstm2_back.parameters():
                param.requires_grad = False
            
            
            # Freeze parameters of the weights
#             w1=np.random.rand(1)
            self.weight1 = nn.Parameter(torch.tensor([np.random.random()], requires_grad=False))
            self.weight2 = nn.Parameter(torch.tensor([np.random.random()], requires_grad=False))
            self.weight3 = nn.Parameter(torch.tensor([np.random.random()], requires_grad=False))
                
            # ELMO prediction
            lstm1_output_f , _ = self.lstm1_forward(embedded_sequence)
            lstm2_output_f , _ = self.lstm2_forward(lstm1_output_f)
            embedded_sequencer= torch.flip(embedded_sequence, [1])
            lstm1_output_r , _= self.lstm1_back(embedded_sequence)
            lstm2_output_r , _ = self.lstm2_back(lstm1_output_r)
            lstm1_output_combined = torch.cat([lstm1_output_f, lstm1_output_r], dim=1)
            lstm2_output_combined = torch.cat([lstm2_output_f, lstm2_output_r], dim=1)
            embed_output_combined = torch.cat([embedded_sequencer,embedded_sequence], dim=1)
            
            
            # Combine LSTM outputs with trainable weights
            weights = torch.softmax(torch.cat([self.weight1, self.weight2, self.weight3]), dim=0)
            weighted_sum = weights[0] * lstm1_output_combined + weights[1] * lstm2_output_combined + weights[2] * embed_output_combined
#             print(len(weighted_sum[0][0])
#             print(type(weighted_sum))
#             print(weighted_sum.shape)
            weighted_sum = weighted_sum.view(-1)
            output_probs = self.output_(weighted_sum)
        elif mode==5:
             # Freeze parameters of the LSTM layers 
            for param in self.lstm1_forward.parameters():
                param.requires_grad = False
            for param in self.lstm2_forward.parameters():
                param.requires_grad = False
            for param in self.lstm1_back.parameters():
                param.requires_grad = False
            for param in self.lstm2_back.parameters():
                param.requires_grad = False
            
            
            # Freeze parameters of the weights
#             w1=np.random.rand(1)
            self.weight1.requires_grad = False
            self.weight2.requires_grad = False
            self.weight3.requires_grad = False
            # ELMO prediction
            lstm1_output_f , _ = self.lstm1_forward(embedded_sequence)
            lstm2_output_f , _ = self.lstm2_forward(lstm1_output_f)
            embedded_sequencer= torch.flip(embedded_sequence, [1])
            lstm1_output_r , _= self.lstm1_back(embedded_sequence)
            lstm2_output_r , _ = self.lstm2_back(lstm1_output_r)
            lstm1_output_combined = torch.cat([lstm1_output_f, lstm1_output_r], dim=1)
            lstm2_output_combined = torch.cat([lstm2_output_f, lstm2_output_r], dim=1)
            embed_output_combined = torch.cat([embedded_sequencer,embedded_sequence], dim=1)
            
            
            # Combine LSTM outputs with trainable weights
            weights = torch.softmax(torch.cat([self.weight1, self.weight2, self.weight3]), dim=0)
            weighted_sum = weights[0] * lstm1_output_combined + weights[1] * lstm2_output_combined + weights[2] * embed_output_combined
#             print(len(weighted_sum[0][0])
#             print(type(weighted_sum))
#             print(weighted_sum.shape)
            weighted_sum = weighted_sum.view(-1)
            output_probs = self.output_(weighted_sum)


        return output_probs




class_index_train = []
description_train = []
class_index_train_elmo = []
description_train_elmo = []
class_index_test = []
description_test = []
pad_token = '<pad>'
desired_length = 50
padded_list = []


csv_file_path = '/kaggle/input/nlp-a4-data/data/test.csv' ##  test path
csv_file_path = '/kaggle/input/nlp-a4-data/data/train.csv' ## train path
word2vec_model = KeyedVectors.load_word2vec_format('/kaggle/input/word2vec/GoogleNews-vectors-negative300.bin', binary=True) ## pretrained model path



### load the train data
with open(csv_file_path, 'r', newline='', encoding='utf-8') as csv_file:
    csv_reader = csv.reader(csv_file)
    
    # Skip the header row if it exists
    next(csv_reader, None)
    
    # Iterate through the rows and extract data
    for row in csv_reader:
        #remove trailing or leading spaces
        class_index = row[0].strip() 
        description = row[1].strip()  
        
        # Append the data to their respective lists
        class_index_train.append(class_index)
        description_train.append(description)
        class_index_train_elmo.append(class_index)
        description_train_elmo.append(description)
        
        
        
### load the test data
        

# Open and read the CSV file
with open(csv_file_path, 'r', newline='', encoding='utf-8') as csv_file:
    csv_reader = csv.reader(csv_file)
    
    # Skip the header row if it exists
    next(csv_reader, None)
    
    # Iterate through the rows and extract data
    for row in csv_reader:
        class_index = row[0].strip()  # Extract and strip the Class Index
        description = row[1].strip()  # Extract and strip the Description
        
        # Append the data to their respective lists
        class_index_test.append(class_index)
        description_test.append(description)


text = ' '.join(description_train_elmo)
test_text = ' '.join(description_test)
words = re.split(r'(?<!\\)\\', text)
train_words = [nltk.word_tokenize(sentence) for sentence in words]
wordss = re.split(r'(?<!\\)\\', test_text)
test_words = [nltk.word_tokenize(sentence) for sentence in wordss]



### to uniform the size of each sentence using padding or truncating
for sentence in test_words:
    if len(sentence) >= desired_length:
        padded_sentence = sentence[:desired_length]
    else:
        num_padding = desired_length - len(sentence)
        padded_sentence = sentence + ([pad_token]* num_padding)
    padded_list.append(padded_sentence)

## create the vocabulary
words = [word for sublist in train_words for word in sublist]
for word in words:
    word.lower()
words = [word for word in words if word not in string.punctuation]
words.append('unk')
vocab=set(words)



# Load the pre-trained Word2Vec model and create an embedding metrix

# Assuming train_vocabulary is a list of words
embedding_dim=300
embedding_matrix=np.zeros((len(vocab),embedding_dim))

for i,word in enumerate(vocab):
    if word in word2vec_model:
        embedding = word2vec_model[word]
    else:
        # Handle missing words by assigning zeros
        embedding = np.random.randn(embedding_dim).astype(np.float32)
    embedding_matrix[i] = embedding
    
    
## map the words to numerical value and store in a dict 
word_to_index = {word: index for index, word in enumerate(vocab)}
index_to_word = {index: word for index, word in enumerate(vocab)}

word_indices = [word_to_index[word] if word in vocab else word_to_index['<UNK>'] for word in words]

## padd the sentence
padded_lists = []
for sentence in padded_list:
    padded_lists.append([word_to_index[word] if word in vocab else word_to_index['unk'] for word in sentence])




### define the hyperparameters to be used to train the model

embedding_dim = 300 # Adjust based on your Word2vec embeddings
hidden_dim = 300  # Adjust as needed
vocab_size = len(vocab)  # Size of your vocabulary
learning_rate = 0.01
epochs = 10  # Number of training epochs
sentence_length = desired_length
# Initialize the model




# Load the model
model_state_dict = torch.load('elmo_model.pth')
model = ELMO(embedding_matrix=torch.from_numpy(embedding_matrix), hidden_dim=hidden_dim, vocab_size=vocab_size, mode = 1,length = sentence_length)


# Load the state dictionary into the model
model.load_state_dict(model_state_dict)

# Define the loss function and optimizer
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=learning_rate)


## preparing the data

elmo = []
for i in range(len(padded_lists)):
    elmo.append((padded_lists[i], class_index_train[i]))


### Downstream task
### the the model will learn the lambas(weights) using the downstream task

# Define the percentage of data to use (e.g., 10%)
data_percentage = 1

# Calculate the number of samples to use
num_samples = int(len(elmo) * data_percentage)

# Randomly select a subset of input_target_pairs
random.seed(42)  # Set a random seed for reproducibility
selected_pairs_elmo = random.sample(elmo, num_samples)



### code to traint the lambdas
from tqdm import tqdm
import torch
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

# Check if a GPU is available, and if not, use CPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
hidden_dimension=300
# Move your model and optimizer to the GPU
model.to(device)
optimizer = torch.optim.Adam(model.parameters())

# Create a progress bar
progress_bar = tqdm(range(epochs), desc="Training")

# Create a data structure to store metrics
metrics_data = []

# Training loop
for epoch in progress_bar:
    total_loss = 0
    all_predicted = []
    all_targets = []

    for input_indices, target_index in selected_pairs_elmo:
        # Move tensors to the GPU
        input_indices = torch.tensor(input_indices, dtype=torch.long).to(device)
        target_index = torch.tensor(int(target_index), dtype=torch.long).to(device)

        optimizer.zero_grad()

        # Forward pass for forward prediction (mode 3)
        forward_output = model(input_indices, mode=3)
        # Calculate the loss for forward prediction
        loss = criterion(forward_output, target_index - 1)

        # Backpropagation and optimization
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

        # Convert the forward output to class predictions
        _, predicted = torch.max(forward_output, dim=0)

        # Ensure predicted is a Python integer
        predicted = int(predicted)
        all_predicted.append(predicted + 1)  # Append to the list
        all_targets.append(int(target_index.cpu().numpy()))  # Move to CPU and convert to NumPy

    # Calculate accuracy and F1 score
    accuracy = accuracy_score(all_targets, all_predicted)
    f1_micro = f1_score(all_targets, all_predicted, average='micro')

    # Calculate confusion matrix
    confusion = confusion_matrix(all_targets, all_predicted)

    # Store metrics for this epoch
    metrics_data.append({'Epoch': epoch + 1, 'Loss': total_loss / len(selected_pairs_elmo), 'Accuracy': accuracy, 'F1 (micro)': f1_micro})

    # Update the progress bar description
    progress_bar.set_description(f"Epoch {epoch + 1}/{epochs}, Loss: {total_loss / len(selected_pairs_elmo):.4f}, Accuracy: {accuracy:.4f}, F1 (micro): {f1_micro:.4f}")

# Close the progress bar
progress_bar.close()


# Create a colored confusion matrix
plt.figure(figsize=(8, 6))
sns.heatmap(confusion, annot=True, fmt='d', cmap='Blues', cbar=False)
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix')
plt.show()


## now using the above model wthe the weights learned will try to do the downstream task (4 class classification)
from tqdm import tqdm
import torch
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

# Check if a GPU is available, and if not, use CPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Move your model and optimizer to the GPU
model.to(device)
optimizer = torch.optim.Adam(model.parameters())

# Create a progress bar
progress_bar = tqdm(range(epochs), desc="Training")

# Create a data structure to store metrics for training and dev
train_metrics_data = []
dev_metrics_data = []

# Create a list to store confusion matrices
train_confusion_matrices = []
dev_confusion_matrices = []

# Separate your dataset into training and dev datasets
train_size = int(0.8 * len(selected_pairs_elmo))  # Use 80% for training, 20% for dev
train_pairs = selected_pairs_elmo[:train_size]
dev_pairs = selected_pairs_elmo[train_size:]

# Training loop
for epoch in progress_bar:
    # Training
    model.train()
    total_loss = 0
    all_predicted = []
    all_targets = []

    for input_indices, target_index in train_pairs:
        # Move tensors to the GPU
        input_indices = torch.tensor(input_indices, dtype=torch.long).to(device)
        target_index = torch.tensor(int(target_index), dtype=torch.long).to(device)

        optimizer.zero_grad()

        # Forward pass for forward prediction (mode 3)
        forward_output = model(input_indices, mode=3)
        # Calculate the loss for forward prediction
        loss = criterion(forward_output, target_index - 1)

        # Backpropagation and optimization
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

        # Convert the forward output to class predictions
        _, predicted = torch.max(forward_output, dim=0)

        # Ensure predicted is a Python integer
        predicted = int(predicted)
        all_predicted.append(predicted + 1)  # Append to the list
        all_targets.append(int(target_index.cpu().numpy()))  # Move to CPU and convert to NumPy

    # Calculate accuracy and F1 score for training
    train_accuracy = accuracy_score(all_targets, all_predicted)
    train_f1_micro = f1_score(all_targets, all_predicted, average='micro')

    # Calculate confusion matrix for training
    train_confusion = confusion_matrix(all_targets, all_predicted)
    train_confusion_matrices.append(train_confusion)

    # Store metrics for training
    train_metrics_data.append({'Epoch': epoch + 1, 'Loss': total_loss / len(train_pairs), 'Accuracy': train_accuracy, 'F1 (micro)': train_f1_micro})

    # Development (Dev)
    model.eval()
    total_loss = 0
    all_predicted = []
    all_targets = []

    for input_indices, target_index in dev_pairs:
        # Move tensors to the GPU
        input_indices = torch.tensor(input_indices, dtype=torch.long).to(device)
        target_index = torch.tensor(int(target_index), dtype=torch.long).to(device)

        # Forward pass for forward prediction (mode 3)
        forward_output = model(input_indices, mode=3)
        # Calculate the loss for forward prediction
        loss = criterion(forward_output, target_index - 1)

        total_loss += loss.item()

        # Convert the forward output to class predictions
        _, predicted = torch.max(forward_output, dim=0)

        # Ensure predicted is a Python integer
        predicted = int(predicted)
        all_predicted.append(predicted + 1)  # Append to the list
        all_targets.append(int(target_index.cpu().numpy()))  # Move to CPU and convert to NumPy

    # Calculate accuracy and F1 score for dev
    dev_accuracy = accuracy_score(all_targets, all_predicted)
    dev_f1_micro = f1_score(all_targets, all_predicted, average='micro')

    # Calculate confusion matrix for dev
    dev_confusion = confusion_matrix(all_targets, all_predicted)
    dev_confusion_matrices.append(dev_confusion)

    # Store metrics for dev
    dev_metrics_data.append({'Epoch': epoch + 1, 'Loss': total_loss / len(dev_pairs), 'Accuracy': dev_accuracy, 'F1 (micro)': dev_f1_micro})

    # Update the progress bar description
    progress_bar.set_description(f"Epoch {epoch + 1}/{epochs}, Train Loss: {train_metrics_data[-1]['Loss']:.4f}, Dev Loss: {dev_metrics_data[-1]['Loss']:.4f}, Train Accuracy: {train_accuracy:.4f}, Dev Accuracy: {dev_accuracy:.4f}")

# Close the progress bar
progress_bar.close()

# Create dataframes from metrics data
train_metrics_df = pd.DataFrame(train_metrics_data)
dev_metrics_df = pd.DataFrame(dev_metrics_data)

# Save metrics as CSV
train_metrics_df.to_csv('train_metrics.csv', index=False)
dev_metrics_df.to_csv('dev_metrics.csv', index=False)

# Plot training and dev accuracy over epochs
plt.figure(figsize=(12, 6))
plt.plot(train_metrics_df['Epoch'], train_metrics_df['Accuracy'], label='Train Accuracy', marker='o')
plt.plot(dev_metrics_df['Epoch'], dev_metrics_df['Accuracy'], label='Dev Accuracy', marker='o')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.title('Training vs. Dev Accuracy')
plt.legend()
plt.show()

# Plot confusion matrices
plt.figure(figsize=(12, 6))
plt.subplot(1, 2, 1)
sns.heatmap(train_confusion_matrices[-1], annot=True, fmt='d', cmap='Blues', cbar=False)
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Train Confusion Matrix')

plt.subplot(1, 2, 2)
sns.heatmap(dev_confusion_matrices[-1], annot=True, fmt='d', cmap='Blues', cbar=False)
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Dev Confusion Matrix')

plt.tight_layout()
plt.show()


### now here the weights will be frozen (randomely initilized) and will do the classification task
from tqdm import tqdm
import torch
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

# Check if a GPU is available, and if not, use CPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
hidden_dimension=300
# Move your model and optimizer to the GPU
model.to(device)
optimizer = torch.optim.Adam(model.parameters())

# Create a progress bar
progress_bar = tqdm(range(epochs), desc="Training")

# Create a data structure to store metrics
metrics_data = []

# Training loop
for epoch in progress_bar:
    total_loss = 0
    all_predicted = []
    all_targets = []

    for input_indices, target_index in selected_pairs_elmo:
        # Move tensors to the GPU
        input_indices = torch.tensor(input_indices, dtype=torch.long).to(device)
        target_index = torch.tensor(int(target_index), dtype=torch.long).to(device)

        optimizer.zero_grad()

     
        forward_output = model(input_indices, mode=4)
        # Calculate the loss for forward prediction
        loss = criterion(forward_output, target_index - 1)

        # Backpropagation and optimization
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

        # Convert the forward output to class predictions
        _, predicted = torch.max(forward_output, dim=0)

        # Ensure predicted is a Python integer
        predicted = int(predicted)
        all_predicted.append(predicted + 1)  # Append to the list
        all_targets.append(int(target_index.cpu().numpy()))  # Move to CPU and convert to NumPy

    # Calculate accuracy and F1 score
    accuracy = accuracy_score(all_targets, all_predicted)
    f1_micro = f1_score(all_targets, all_predicted, average='micro')

    # Calculate confusion matrix
    confusion = confusion_matrix(all_targets, all_predicted)

    # Store metrics for this epoch
    metrics_data.append({'Epoch': epoch + 1, 'Loss': total_loss / len(selected_pairs_elmo), 'Accuracy': accuracy, 'F1 (micro)': f1_micro})

    # Update the progress bar description
    progress_bar.set_description(f"Epoch {epoch + 1}/{epochs}, Loss: {total_loss / len(selected_pairs_elmo):.4f}, Accuracy: {accuracy:.4f}, F1 (micro): {f1_micro:.4f}")

# Close the progress bar
progress_bar.close()

# Create a colored confusion matrix
plt.figure(figsize=(4, 4))
sns.heatmap(confusion, annot=True, fmt='d', cmap='Blues', cbar=False)
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix')
plt.show()



from tqdm import tqdm
import torch
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

# Check if a GPU is available, and if not, use CPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Move your model and optimizer to the GPU
model.to(device)
optimizer = torch.optim.Adam(model.parameters())

# Create a progress bar
progress_bar = tqdm(range(epochs), desc="Training")

# Create a data structure to store metrics for training and dev
train_metrics_data = []
dev_metrics_data = []

# Create a list to store confusion matrices
train_confusion_matrices = []
dev_confusion_matrices = []

# Separate your dataset into training and dev datasets
train_size = int(0.8 * len(selected_pairs_elmo))  # Use 80% for training, 20% for dev
train_pairs = selected_pairs_elmo[:train_size]
dev_pairs = selected_pairs_elmo[train_size:]

# Training loop
for epoch in progress_bar:
    # Training
    model.train()
    total_loss = 0
    all_predicted = []
    all_targets = []

    for input_indices, target_index in train_pairs:
        # Move tensors to the GPU
        input_indices = torch.tensor(input_indices, dtype=torch.long).to(device)
        target_index = torch.tensor(int(target_index), dtype=torch.long).to(device)

        optimizer.zero_grad()

        # Forward pass for forward prediction (mode 3)
        forward_output = model(input_indices, mode=3)
        # Calculate the loss for forward prediction
        loss = criterion(forward_output, target_index - 1)

        # Backpropagation and optimization
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

        # Convert the forward output to class predictions
        _, predicted = torch.max(forward_output, dim=0)

        # Ensure predicted is a Python integer
        predicted = int(predicted)
        all_predicted.append(predicted + 1)  # Append to the list
        all_targets.append(int(target_index.cpu().numpy()))  # Move to CPU and convert to NumPy

    # Calculate accuracy and F1 score for training
    train_accuracy = accuracy_score(all_targets, all_predicted)
    train_f1_micro = f1_score(all_targets, all_predicted, average='micro')

    # Calculate confusion matrix for training
    train_confusion = confusion_matrix(all_targets, all_predicted)
    train_confusion_matrices.append(train_confusion)

    # Store metrics for training
    train_metrics_data.append({'Epoch': epoch + 1, 'Loss': total_loss / len(train_pairs), 'Accuracy': train_accuracy, 'F1 (micro)': train_f1_micro})

    # Development (Dev)
    model.eval()
    total_loss = 0
    all_predicted = []
    all_targets = []

    for input_indices, target_index in dev_pairs:
        # Move tensors to the GPU
        input_indices = torch.tensor(input_indices, dtype=torch.long).to(device)
        target_index = torch.tensor(int(target_index), dtype=torch.long).to(device)

        # Forward pass for forward prediction (mode 3)
        forward_output = model(input_indices, mode=3)
        # Calculate the loss for forward prediction
        loss = criterion(forward_output, target_index - 1)

        total_loss += loss.item()

        # Convert the forward output to class predictions
        _, predicted = torch.max(forward_output, dim=0)

        # Ensure predicted is a Python integer
        predicted = int(predicted)
        all_predicted.append(predicted + 1)  # Append to the list
        all_targets.append(int(target_index.cpu().numpy()))  # Move to CPU and convert to NumPy

    # Calculate accuracy and F1 score for dev
    dev_accuracy = accuracy_score(all_targets, all_predicted)
    dev_f1_micro = f1_score(all_targets, all_predicted, average='micro')

    # Calculate confusion matrix for dev
    dev_confusion = confusion_matrix(all_targets, all_predicted)
    dev_confusion_matrices.append(dev_confusion)

    # Store metrics for dev
    dev_metrics_data.append({'Epoch': epoch + 1, 'Loss': total_loss / len(dev_pairs), 'Accuracy': dev_accuracy, 'F1 (micro)': dev_f1_micro})

    # Update the progress bar description
    progress_bar.set_description(f"Epoch {epoch + 1}/{epochs}, Train Loss: {train_metrics_data[-1]['Loss']:.4f}, Dev Loss: {dev_metrics_data[-1]['Loss']:.4f}, Train Accuracy: {train_accuracy:.4f}, Dev Accuracy: {dev_accuracy:.4f}")

# Close the progress bar
progress_bar.close()

# Create dataframes from metrics data
train_metrics_df = pd.DataFrame(train_metrics_data)
dev_metrics_df = pd.DataFrame(dev_metrics_data)

# Save metrics as CSV
train_metrics_df.to_csv('train_metrics.csv', index=False)
dev_metrics_df.to_csv('dev_metrics.csv', index=False)

# Plot training and dev accuracy over epochs
plt.figure(figsize=(12, 6))
plt.plot(train_metrics_df['Epoch'], train_metrics_df['Accuracy'], label='Train Accuracy', marker='o')
plt.plot(dev_metrics_df['Epoch'], dev_metrics_df['Accuracy'], label='Dev Accuracy', marker='o')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.title('Training vs. Dev Accuracy')
plt.legend()
plt.show()

# Plot confusion matrices
plt.figure(figsize=(12, 6))
plt.subplot(1, 2, 1)
sns.heatmap(train_confusion_matrices[-1], annot=True, fmt='d', cmap='Blues', cbar=False)
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Train Confusion Matrix')

plt.subplot(1, 2, 2)
sns.heatmap(dev_confusion_matrices[-1], annot=True, fmt='d', cmap='Blues', cbar=False)
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Dev Confusion Matrix')

plt.tight_layout()
plt.show()



### now the model will be saved in the given directory
file_path = '/kaggle/working/classificaion_model.pth'

# Save the model to the specified file
torch.save(model.state_dict(), file_path)

print(f"Model saved to {file_path}")