import torch
# import modules
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import matplotlib.pyplot as plt
import numpy as np
import nltk
from nltk.tokenize import word_tokenize
import string
nltk.download('punkt')  # Make sure you have the punkt tokenizer data downloaded
import csv
import re
import random
import copy
from gensim.models import KeyedVectors
import numpy as np
import random





## device 
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


class_index_train = []
description_train = []
class_index_train_elmo = []
description_train_elmo = []
class_index_test = []
description_test = []
pad_token = '<pad>'
desired_length = 50
padded_list = []


csv_file_path = '/kaggle/input/nlp-a4-data/data/test.csv' ##  test path
csv_file_path = '/kaggle/input/nlp-a4-data/data/train.csv' ## train path
word2vec_model = KeyedVectors.load_word2vec_format('/kaggle/input/word2vec/GoogleNews-vectors-negative300.bin', binary=True) ## pretrained model path



### load the train data
with open(csv_file_path, 'r', newline='', encoding='utf-8') as csv_file:
    csv_reader = csv.reader(csv_file)
    
    # Skip the header row if it exists
    next(csv_reader, None)
    
    # Iterate through the rows and extract data
    for row in csv_reader:
        #remove trailing or leading spaces
        class_index = row[0].strip() 
        description = row[1].strip()  
        
        # Append the data to their respective lists
        class_index_train.append(class_index)
        description_train.append(description)
        class_index_train_elmo.append(class_index)
        description_train_elmo.append(description)
        
        
        
### load the test data
        

# Open and read the CSV file
with open(csv_file_path, 'r', newline='', encoding='utf-8') as csv_file:
    csv_reader = csv.reader(csv_file)
    
    # Skip the header row if it exists
    next(csv_reader, None)
    
    # Iterate through the rows and extract data
    for row in csv_reader:
        class_index = row[0].strip()  # Extract and strip the Class Index
        description = row[1].strip()  # Extract and strip the Description
        
        # Append the data to their respective lists
        class_index_test.append(class_index)
        description_test.append(description)


text = ' '.join(description_train_elmo)
test_text = ' '.join(description_test)
words = re.split(r'(?<!\\)\\', text)
train_words = [nltk.word_tokenize(sentence) for sentence in words]
wordss = re.split(r'(?<!\\)\\', test_text)
test_words = [nltk.word_tokenize(sentence) for sentence in wordss]



### to uniform the size of each sentence using padding or truncating
for sentence in test_words:
    if len(sentence) >= desired_length:
        padded_sentence = sentence[:desired_length]
    else:
        num_padding = desired_length - len(sentence)
        padded_sentence = sentence + ([pad_token]* num_padding)
    padded_list.append(padded_sentence)

## create the vocabulary
words = [word for sublist in train_words for word in sublist]
for word in words:
    word.lower()
words = [word for word in words if word not in string.punctuation]
words.append('unk')
vocab=set(words)



# Load the pre-trained Word2Vec model and create an embedding metrix

# Assuming train_vocabulary is a list of words
embedding_dim=300
embedding_matrix=np.zeros((len(vocab),embedding_dim))

for i,word in enumerate(vocab):
    if word in word2vec_model:
        embedding = word2vec_model[word]
    else:
        # Handle missing words by assigning zeros
        embedding = np.random.randn(embedding_dim).astype(np.float32)
    embedding_matrix[i] = embedding
    
    
## map the words to numerical value and store in a dict 
word_to_index = {word: index for index, word in enumerate(vocab)}
index_to_word = {index: word for index, word in enumerate(vocab)}

word_indices = [word_to_index[word] if word in vocab else word_to_index['<UNK>'] for word in words]

## padd the sentence
padded_lists = []
for sentence in padded_list:
    padded_lists.append([word_to_index[word] if word in vocab else word_to_index['unk'] for word in sentence])


### crate the n gram configuration to train the Elmo model (bi-Lstm)
n = 7  # Define the n-gram size (6 + 1)

# Initialize a list to store input and target pairs
input_target_pairs = []
# Create input and target pairs
for i in range(len(word_indices) - n + 1):
    input_indices = word_indices[i:i+6]
    target_index = word_indices[i+6]
    input_target_pairs.append((input_indices, target_index))



### define the Elmo class
class ELMO(nn.Module):

    def __init__(self, embedding_matrix, hidden_dim, vocab_size, mode, length ):
        super(ELMO, self).__init__()

        self.hidden_dim = hidden_dim

        # Embedding layer with pretrained embeddings
        self.embedding = nn.Embedding.from_pretrained(embedding_matrix)

        # First LSTM layer
        self.lstm1_forward = nn.LSTM(input_size=embedding_matrix.shape[1], hidden_size=hidden_dim, batch_first=True)

        # Second LSTM layer
        self.lstm2_forward = nn.LSTM(input_size=hidden_dim, hidden_size=hidden_dim, batch_first=True)
        
        self.output_layer_front = nn.Linear(hidden_dim, vocab_size)

        # backward model 
        
        # Output layer with output dimension vocab_size
        
        self.lstm1_back = nn.LSTM(input_size=embedding_matrix.shape[1], hidden_size=hidden_dim, batch_first=True)

        # Second LSTM layer
        self.lstm2_back = nn.LSTM(input_size=hidden_dim, hidden_size=hidden_dim, batch_first=True)

        # Output layer with output dimension vocab_size
        self.output_layer_back = nn.Linear(hidden_dim, vocab_size)
        
        
#         ELMO
        weight_value = 0.33
        self.weight1 = nn.Parameter(torch.tensor([weight_value], requires_grad=True))
        self.weight2 = nn.Parameter(torch.tensor([weight_value], requires_grad=True))
        self.weight3 = nn.Parameter(torch.tensor([weight_value], requires_grad=True))
        
        
        ### Learnable Function
        self.output_= nn.Linear(50*600 , 4)

    def forward(self,  input_indices, mode):
        embedded_sequence = self.embedding(input_indices)
        embedded_sequence = embedded_sequence.to(self.lstm1_forward.weight_ih_l0.dtype)

        if mode == 1:
            # Forward prediction
            lstm1_output, _ = self.lstm1_forward(embedded_sequence)
            lstm2_output, _ = self.lstm2_forward(lstm1_output)
            output_probs = self.output_layer_front(lstm2_output[:, -1, :])
        elif mode == 2 :

            lstm1_output, _ = self.lstm1_back(embedded_sequence)
            lstm2_output, _ = self.lstm2_back(lstm1_output)
            output_probs = self.output_layer_back(lstm2_output[:, -1, :])
        elif mode == 3:
            # Freeze parameters of the LSTM layers
            for param in self.lstm1_forward.parameters():
                param.requires_grad = False
            for param in self.lstm2_forward.parameters():
                param.requires_grad = False
            for param in self.lstm1_back.parameters():
                param.requires_grad = False
            for param in self.lstm2_back.parameters():
                param.requires_grad = False
                
            # ELMO prediction
            lstm1_output_f , _ = self.lstm1_forward(embedded_sequence)
            lstm2_output_f , _ = self.lstm2_forward(lstm1_output_f)
            embedded_sequencer= torch.flip(embedded_sequence, [1])
            lstm1_output_r , _= self.lstm1_back(embedded_sequence)
            lstm2_output_r , _ = self.lstm2_back(lstm1_output_r)
            lstm1_output_combined = torch.cat([lstm1_output_f, lstm1_output_r], dim=1)
            lstm2_output_combined = torch.cat([lstm2_output_f, lstm2_output_r], dim=1)
            embed_output_combined = torch.cat([embedded_sequencer,embedded_sequence], dim=1)
            
            
            # Combine LSTM outputs with trainable weights
            weights = torch.softmax(torch.cat([self.weight1, self.weight2, self.weight3]), dim=0)
            weighted_sum = weights[0] * lstm1_output_combined + weights[1] * lstm2_output_combined + weights[2] * embed_output_combined
#             print(len(weighted_sum[0][0]))
#             print("entered")
#             print(weighted_sum.shape)
            weighted_sum = weighted_sum.view(-1)
            output_probs = self.output_(weighted_sum)
        elif mode==4:
             # Freeze parameters of the LSTM layers 
            for param in self.lstm1_forward.parameters():
                param.requires_grad = False
            for param in self.lstm2_forward.parameters():
                param.requires_grad = False
            for param in self.lstm1_back.parameters():
                param.requires_grad = False
            for param in self.lstm2_back.parameters():
                param.requires_grad = False
            
            
            # Freeze parameters of the weights
#             w1=np.random.rand(1)
            self.weight1 = nn.Parameter(torch.tensor([np.random.random()], requires_grad=False))
            self.weight2 = nn.Parameter(torch.tensor([np.random.random()], requires_grad=False))
            self.weight3 = nn.Parameter(torch.tensor([np.random.random()], requires_grad=False))
                
            # ELMO prediction
            lstm1_output_f , _ = self.lstm1_forward(embedded_sequence)
            lstm2_output_f , _ = self.lstm2_forward(lstm1_output_f)
            embedded_sequencer= torch.flip(embedded_sequence, [1])
            lstm1_output_r , _= self.lstm1_back(embedded_sequence)
            lstm2_output_r , _ = self.lstm2_back(lstm1_output_r)
            lstm1_output_combined = torch.cat([lstm1_output_f, lstm1_output_r], dim=1)
            lstm2_output_combined = torch.cat([lstm2_output_f, lstm2_output_r], dim=1)
            embed_output_combined = torch.cat([embedded_sequencer,embedded_sequence], dim=1)
            
            
            # Combine LSTM outputs with trainable weights
            weights = torch.softmax(torch.cat([self.weight1, self.weight2, self.weight3]), dim=0)
            weighted_sum = weights[0] * lstm1_output_combined + weights[1] * lstm2_output_combined + weights[2] * embed_output_combined
#             print(len(weighted_sum[0][0])
#             print(type(weighted_sum))
#             print(weighted_sum.shape)
            weighted_sum = weighted_sum.view(-1)
            output_probs = self.output_(weighted_sum)
        elif mode==5:
             # Freeze parameters of the LSTM layers 
            for param in self.lstm1_forward.parameters():
                param.requires_grad = False
            for param in self.lstm2_forward.parameters():
                param.requires_grad = False
            for param in self.lstm1_back.parameters():
                param.requires_grad = False
            for param in self.lstm2_back.parameters():
                param.requires_grad = False
            
            
            # Freeze parameters of the weights
#             w1=np.random.rand(1)
            self.weight1.requires_grad = False
            self.weight2.requires_grad = False
            self.weight3.requires_grad = False
            # ELMO prediction
            lstm1_output_f , _ = self.lstm1_forward(embedded_sequence)
            lstm2_output_f , _ = self.lstm2_forward(lstm1_output_f)
            embedded_sequencer= torch.flip(embedded_sequence, [1])
            lstm1_output_r , _= self.lstm1_back(embedded_sequence)
            lstm2_output_r , _ = self.lstm2_back(lstm1_output_r)
            lstm1_output_combined = torch.cat([lstm1_output_f, lstm1_output_r], dim=1)
            lstm2_output_combined = torch.cat([lstm2_output_f, lstm2_output_r], dim=1)
            embed_output_combined = torch.cat([embedded_sequencer,embedded_sequence], dim=1)
            
            
            # Combine LSTM outputs with trainable weights
            weights = torch.softmax(torch.cat([self.weight1, self.weight2, self.weight3]), dim=0)
            weighted_sum = weights[0] * lstm1_output_combined + weights[1] * lstm2_output_combined + weights[2] * embed_output_combined
#             print(len(weighted_sum[0][0])
#             print(type(weighted_sum))
#             print(weighted_sum.shape)
            weighted_sum = weighted_sum.view(-1)
            output_probs = self.output_(weighted_sum)


        return output_probs


### define the hyperparameters to be used to train the model

embedding_dim = 300 # Adjust based on your Word2vec embeddings
hidden_dim = 300  # Adjust as needed
vocab_size = len(vocab)  # Size of your vocabulary
learning_rate = 0.01
epochs = 10  # Number of training epochs
sentence_length = desired_length
# Initialize the model
model = ELMO(embedding_matrix=torch.from_numpy(embedding_matrix), hidden_dim=hidden_dim, vocab_size=vocab_size, mode = 1,length = sentence_length)

# Define the loss function and optimizer
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=learning_rate)


## for backward model training 
com = []
rev = []
elmo = []
input_target_pairs_rev = []
for input_indices, target_index in input_target_pairs:
    com = input_indices + [target_index]  # Convert target_index to a list before concatenation
    rev.append(list(reversed(com)))  # Reverse the list and convert it to a list

for word in rev:
    input_indices = word[:6]
    target_index = word[-1]
    input_target_pairs_rev.append((input_indices, target_index))
for i in range(len(padded_lists)):
    elmo.append((padded_lists[i], class_index_train[i]))
    
    
    
# Define the percentage of data to use (e.g., 10%)
data_percentage = 0.1
# Calculate the number of samples to use
num_samples = int(len(input_target_pairs) * data_percentage)
# Randomly select a subset of input_target_pairs
random.seed(42)  # Set a random seed for reproducibility
selected_pairs = random.sample(input_target_pairs, num_samples)



### code to train the model(forward propagation)
from tqdm import tqdm
import torch
from torch.utils.data import DataLoader, TensorDataset
import numpy as np
import matplotlib.pyplot as plt  # Import Matplotlib

# Move your model and optimizer to the GPU
model.to(device)
optimizer = torch.optim.Adam(model.parameters())

# Split your data into training and validation sets
split_ratio = 0.9  # Adjust as needed
split_idx = int(len(selected_pairs) * split_ratio)
train_pairs = selected_pairs[:split_idx]
valid_pairs = selected_pairs[split_idx:]

# Define your batch size
batch_size = 32

# Lists to store training and validation loss values
train_losses = []
valid_losses = []

# Training loop
epochs = 10  # Adjust the number of epochs as needed
for epoch in range(epochs):
    total_loss = 0

    # Create data loaders for the training and validation sets
    train_inputs, train_targets = zip(*train_pairs)
    train_inputs = torch.tensor(train_inputs, dtype=torch.long).to(device)
    train_targets = torch.tensor(train_targets, dtype=torch.long).to(device)

    train_data = TensorDataset(train_inputs, train_targets)
    train_loader = DataLoader(train_data, batch_size=batch_size, shuffle=True)

    valid_inputs, valid_targets = zip(*valid_pairs)
    valid_inputs = torch.tensor(valid_inputs, dtype=torch.long).to(device)
    valid_targets = torch.tensor(valid_targets, dtype=torch.long).to(device)

    valid_data = TensorDataset(valid_inputs, valid_targets)
    valid_loader = DataLoader(valid_data, batch_size=batch_size)

    # Training
    model.train()
    for batch_inputs, batch_targets in train_loader:
        optimizer.zero_grad()

        # Forward pass for forward prediction (mode 1)
        forward_output = model(batch_inputs, mode=1)
        # Calculate the loss for forward prediction
        loss = criterion(forward_output.view(-1, vocab_size), batch_targets.view(-1))

        # Backpropagation and optimization
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    # Validation
    model.eval()
    with torch.no_grad():
        valid_loss = 0
        num_batches = 0

        for batch_inputs, batch_targets in valid_loader:
            # Forward pass for forward prediction (mode 1)
            forward_output = model(batch_inputs, mode=1)
            # Calculate the loss for forward prediction
            loss = criterion(forward_output.view(-1, vocab_size), batch_targets.view(-1))

            valid_loss += loss.item()
            num_batches += 1

        avg_valid_loss = valid_loss / num_batches

    # Append the training and validation loss values to the lists
    train_losses.append(total_loss / len(train_pairs))
    valid_losses.append(avg_valid_loss)

    # Update the progress bar description with the current losses
    progress_description = f"Epoch {epoch + 1}/{epochs}, Train Loss: {train_losses[-1]:.4f}, Valid Loss: {valid_losses[-1]:.4f}"
    tqdm.write(progress_description)

# Plotting the training and validation losses
plt.figure(figsize=(10, 6))
plt.plot(range(1, epochs + 1), train_losses, label='Train Loss', marker='o')
plt.plot(range(1, epochs + 1), valid_losses, label='Valid Loss', marker='o')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Training and Validation Losses')
plt.legend()
plt.grid()
plt.show()


## data for backward propagation
# Define the percentage of data to use (e.g., 10%)
data_percentage = 0.1

# Calculate the number of samples to use
num_samples = int(len(input_target_pairs_rev) * data_percentage)

# Randomly select a subset of input_target_pairs
random.seed(42)  # Set a random seed for reproducibility
selected_pairs_rev = random.sample(input_target_pairs_rev, num_samples)


### code to train the backward model

from tqdm import tqdm
import torch
import matplotlib.pyplot as plt  # Import Matplotlib

# Check if a GPU is available, and if not, use CPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Move your model and optimizer to the GPU
model.to(device)
optimizer = torch.optim.Adam(model.parameters())

# Split your data into training and validation sets
split_ratio = 0.9  # Adjust as needed
split_idx = int(len(selected_pairs_rev) * split_ratio)
train_pairs = selected_pairs_rev[:split_idx]
valid_pairs = selected_pairs_rev[split_idx:]

# Define your batch size
batch_size = 32

# Lists to store training and validation loss values
train_losses = []
valid_losses = []

# Training loop
epochs = 10  # Adjust the number of epochs as needed
for epoch in range(epochs):
    total_loss = 0

    # Create data loaders for the training and validation sets
    train_inputs, train_targets = zip(*train_pairs)
    train_inputs = torch.tensor(train_inputs, dtype=torch.long).to(device)
    train_targets = torch.tensor(train_targets, dtype=torch.long).to(device)

    train_data = TensorDataset(train_inputs, train_targets)
    train_loader = DataLoader(train_data, batch_size=batch_size, shuffle=True)

    valid_inputs, valid_targets = zip(*valid_pairs)
    valid_inputs = torch.tensor(valid_inputs, dtype=torch.long).to(device)
    valid_targets = torch.tensor(valid_targets, dtype=torch.long).to(device)

    valid_data = TensorDataset(valid_inputs, valid_targets)
    valid_loader = DataLoader(valid_data, batch_size=batch_size)

    # Training
    model.train()
    for batch_inputs, batch_targets in train_loader:
        optimizer.zero_grad()

        # Forward pass for forward prediction (mode 1)
        forward_output = model(batch_inputs, mode=2)
        # Calculate the loss for forward prediction
        loss = criterion(forward_output.view(-1, vocab_size), batch_targets.view(-1))

        # Backpropagation and optimization
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    # Validation
    model.eval()
    with torch.no_grad():
        valid_loss = 0
        num_batches = 0

        for batch_inputs, batch_targets in valid_loader:
            # Forward pass for forward prediction (mode 1)
            forward_output = model(batch_inputs, mode=2)
            # Calculate the loss for forward prediction
            loss = criterion(forward_output.view(-1, vocab_size), batch_targets.view(-1))

            valid_loss += loss.item()
            num_batches += 1

        avg_valid_loss = valid_loss / num_batches

    # Append the training and validation loss values to the lists
    train_losses.append(total_loss / len(train_pairs))
    valid_losses.append(avg_valid_loss)

    # Update the progress bar description with the current losses
    progress_description = f"Epoch {epoch + 1}/{epochs}, Train Loss: {train_losses[-1]:.4f}, Valid Loss: {avg_valid_loss:.4f}"
    tqdm.write(progress_description)

# Plotting the training and validation losses
plt.figure(figsize=(10, 6))
plt.plot(range(1, epochs + 1), train_losses, label='Train Loss', marker='o')
plt.plot(range(1, epochs + 1), valid_losses, label='Valid Loss', marker='o')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Training and Validation Losses')
plt.legend()
plt.grid()
plt.show()





### Downstream task
### the the model will learn the lambas(weights) using the downstream task

# Define the percentage of data to use (e.g., 10%)
data_percentage = 1

# Calculate the number of samples to use
num_samples = int(len(elmo) * data_percentage)

# Randomly select a subset of input_target_pairs
random.seed(42)  # Set a random seed for reproducibility
selected_pairs_elmo = random.sample(elmo, num_samples)



### code to traint the lambdas
from tqdm import tqdm
import torch
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

# Check if a GPU is available, and if not, use CPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
hidden_dimension=300
# Move your model and optimizer to the GPU
model.to(device)
optimizer = torch.optim.Adam(model.parameters())

# Create a progress bar
progress_bar = tqdm(range(epochs), desc="Training")

# Create a data structure to store metrics
metrics_data = []

# Training loop
for epoch in progress_bar:
    total_loss = 0
    all_predicted = []
    all_targets = []

    for input_indices, target_index in selected_pairs_elmo:
        # Move tensors to the GPU
        input_indices = torch.tensor(input_indices, dtype=torch.long).to(device)
        target_index = torch.tensor(int(target_index), dtype=torch.long).to(device)

        optimizer.zero_grad()

        # Forward pass for forward prediction (mode 3)
        forward_output = model(input_indices, mode=3)
        # Calculate the loss for forward prediction
        loss = criterion(forward_output, target_index - 1)

        # Backpropagation and optimization
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

        # Convert the forward output to class predictions
        _, predicted = torch.max(forward_output, dim=0)

        # Ensure predicted is a Python integer
        predicted = int(predicted)
        all_predicted.append(predicted + 1)  # Append to the list
        all_targets.append(int(target_index.cpu().numpy()))  # Move to CPU and convert to NumPy

    # Calculate accuracy and F1 score
    accuracy = accuracy_score(all_targets, all_predicted)
    f1_micro = f1_score(all_targets, all_predicted, average='micro')

    # Calculate confusion matrix
    confusion = confusion_matrix(all_targets, all_predicted)

    # Store metrics for this epoch
    metrics_data.append({'Epoch': epoch + 1, 'Loss': total_loss / len(selected_pairs_elmo), 'Accuracy': accuracy, 'F1 (micro)': f1_micro})

    # Update the progress bar description
    progress_bar.set_description(f"Epoch {epoch + 1}/{epochs}, Loss: {total_loss / len(selected_pairs_elmo):.4f}, Accuracy: {accuracy:.4f}, F1 (micro): {f1_micro:.4f}")

# Close the progress bar
progress_bar.close()


# Create a colored confusion matrix
plt.figure(figsize=(8, 6))
sns.heatmap(confusion, annot=True, fmt='d', cmap='Blues', cbar=False)
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix')
plt.show()

### now the model will be saved in the given directory
file_path = '/kaggle/working/elmo_model.pth'

# Save the model to the specified file
torch.save(model.state_dict(), file_path)

print(f"Model saved to {file_path}")