from custom_tokenizer import custom_tokenizer 
import random
random.seed(0)
import math
import sys
import numpy as np
from scipy.stats import linregress
from n_gram import n_gram 


### good turing
from collections import Counter

class N_Gram_Model:
    y1=y2=y3=0
    corpus=[]
    train_corpus=[]
    test_corpus=[]
    text=""
    unigram={}
    bigram={}
    trigram={}
    probabilities={}
    good_tuning_probailities={}
    sentenc_perplexcity_score={}
    bigram_model = {}
    trigram_model = {}
    perplexity_entire_corpus=0
    freq_freq=[]
    r=[]
    zr=[]
    slope=0
    intercept=0
    rev_nr=[]
    def _init_(self):
        pass
        
    def read_file(self,file_path):

        with open(file_path, 'r') as file:
           self.text= file.read()
        
    
    def setup(self):
        self.corpus=custom_tokenizer(self.text)
        self.test_corpus=self.corpus[-1000:]
        self.train_corpus=[list for list in self.corpus if list  not in self.test_corpus]
     

        self.trigram_model = n_gram(3, self.train_corpus)
        self.bigram_model = n_gram(2, self.train_corpus)
    
    ### functions for interpolation
    def unigram_probability(self,word):
        if word in self.unigram:
            return self.unigram[word]/len(self.unigram)
        else:
            return 0
        
    ## function to calculate the bigram probability      
    def bigram_probability(self,word):
        if word in self.bigram:
            count = self.bigram_model[word[:-1]].get(word[-1:], 0)
            ts=sum(val for val in self.bigram_model[word[:-1]].values())
            return count/ts
        else:
            return 0

    def trigram_probability(self,word):
        if word in self.trigram:
            count = self.trigram_model[word[:-1]].get(word[-1:], 0)
            ts=sum(val for val in self.trigram_model[word[:-1]].values())
            return count/ts
        else:
            return 0   
        


   
   
    def sort_freq_freq(self):
        my_d=dict(self.freq_freq)
        # Sort the dictionary by keys in descending order
        self.freq_freq = dict(sorted(my_d.items()))    
        self.r=list(self.freq_freq.keys())
    def cal_nr(self):
        self.freq_freq=Counter(self.trigram.values())
        

    def cal_zr(self):
        
        x=(self.freq_freq[self.r[0]])/(2*(self.r[1]))
        self.zr.append(x)


        for i in range (1,len(self.r)-1):
            x=(2*self.freq_freq[self.r[i]]/((self.r[i+1]-self.r[i-1])))
            self.zr.append(x)
        n=len(self.r)
        x=(2*self.freq_freq[self.r[n-1]])/((self.r[n-1]-self.r[n-2]))
        self.zr.append(x)

    def linear_fit(self):
        self.slope, self.intercept,_ ,_ ,_ = linregress(np.log(self.r), np.log(self.zr))

    def cal_prob(self,tupel):
        if tupel not in self.trigram:
            return 0
        r=self.trigram[tupel]
        den=1.0
  
        if(r):
            den=self.intercept+self.slope*np.log(r)
        num=float(self.intercept+self.slope*np.log(r+1))
       
        return (r+1)*num/den
    
    def cal_gt_prob(self):

    
        for tup in self.trigram:
            num=self.cal_prob(tup)
            den=1
            bi_tup=tup[:-1]
            for uni in self.unigram:
                temp_tpl=bi_tup+uni
                den+=self.cal_prob(temp_tpl)

            self.good_tuning_probailities[tup]=num/den 

    def sentence_logprob_g(self, sentence):
        ngrams_3 = [tuple(sentence[i:i+3]) for i in range(len(sentence)-2)]
        p=1
        for trigram in ngrams_3: 
            p *= (self.good_tuning_probailities.get(trigram, 1e-10))  # Smoothing added
        n=len(ngrams_3) 
        # print(p)
        

        if n>=1 and p>0:  
            pscore=pow(p,-1/n)
        else:
                pscore=0
            
        self.sentenc_perplexcity_score[tuple(sentence)] = pscore
        return pscore
    def sentence_logprob_i(self, sentence):
        ngrams_3 = [tuple(sentence[i:i+3]) for i in range(len(sentence)-2)]
        p=1
        for trigram in ngrams_3: 
            p *= (self.probabilities.get(trigram, 1e-10))  # Smoothing added
        n=len(ngrams_3) 
        # print(p)
        
    
        if n>=1 and p>0:  
            pscore=pow(p,-1/n)
        else:
             pscore=0
            
        self.sentenc_perplexcity_score[tuple(sentence)] = pscore
        return pscore
    
    
### function to calculate the perplexcity of the entire sequence.    
    def perplexity(self,data,type):
    

        sum = 0 
        count = 0 
        for sentence in data: 
            if(type=='i'):
                sum += self.sentence_logprob_i(sentence) 
            else:
                sum += self.sentence_logprob_g(sentence) 
            count += 1
        
        return sum/count
    



    def predict_lamda(self):
      
        y1=y2=y3=0
        for data in self.trigram:
            maxx_model=0
            maxx_val=0
            zero=0
    
            if self.bigram[data[:-1]]-1 == 0:
                curr3 = 0
            else:
                curr3=float(self.trigram[data]-1)/(self.bigram[data[:-1]]-1)
            
            if(curr3>maxx_val):
                maxx_val=curr3
                maxx_model=3
                
            # case 2    
            if (self.unigram[data[1:2]]-1) == 0:
                curr2 = 0
            else:
                curr2=float(self.bigram[data[1:3]]-1)/(self.unigram[data[1:2]]-1)

            if(curr2>maxx_val):
                maxx_val=curr2
                maxx_model=2
            
            #case 3
            if len(self.unigram)-1 == 0:
                curr1 = 0
            else:
                curr1=float(self.unigram[data[-1:]]-1)/(len(self.unigram)-1)
            if(curr1>maxx_val):
                    maxx_val=curr1
                    maxx_model=1
            
            if  maxx_model==1:
                y1+=self.trigram[data]
            elif maxx_model==2:
                y2+=self.trigram[data] 
            else:
                y3+=self.trigram[data]
       
        y_sum=y1+y2+y3

        self.y1=y1/y_sum
        self.y2=y2/y_sum
        self.y3=y3/y_sum
        
        ### calculating the probabiliy for each trigram:
        
        for tup in self.trigram:
            p1=self.unigram_probability(tup[-1])
            p2=self.bigram_probability(tup[1:])
            p3=self.trigram_probability(tup)
            prob=self.y1*p1+ self.y2*p2+self.y3*p3
            self.probabilities[tup]=prob
        
       
    def train(self,type):
        tokens=self.train_corpus
        for sentence in tokens:
            sentence = ["start"] + ["start"] + sentence + ["end"]
            ngrams_3 =[tuple(sentence[i:i+3]) for  i   in range(len(sentence)-3)]
            for gram in ngrams_3:
                if gram in self.trigram:
                    self.trigram[gram]+=1
                else:
                    self.trigram[gram]=1
        
        for sentence in tokens:
            sentence = ["start"] + ["start"] + sentence + ["end"]
            ngrams_2 =[tuple(sentence[i:i+2]) for  i in range(len(sentence)-2)]
            for gram in ngrams_2:
                if gram in self.bigram:
                    self.bigram[gram]+=1
                else:
                    self.bigram[gram]=1
        for sentence in tokens:
            sentence = sentence + ["end"]
            ngrams_1 =[tuple(sentence[i:i+1])  for   i in range(len(sentence)-1)]
            for gram in ngrams_1:
                if gram in self.unigram:
                    self.unigram[gram]+=1
                else:
                    self.unigram[gram]=1
                     

        if(type=='i'):
            self.predict_lamda()
           
                   
    def save():
        pass
    

def main():
    if len(sys.argv) != 4:
        print(len(sys.argv))
        print("Usage: generator.py <lm_type> <corpus_path> <k>")
        sys.exit(1)

    lm_type = sys.argv[1]
    corpus_path = sys.argv[2]
    k = int(sys.argv[3])

    # Now you have lm_type, corpus_path, and k available for further processing
    print("LM Type:", lm_type)
    print("Corpus Path:", corpus_path)
    print("K:", k)

    model=N_Gram_Model()
    model.read_file(corpus_path)
    model.setup()
    model.train(lm_type)
    if(lm_type=='g'):
        model.cal_nr()
        model.sort_freq_freq()
        
        model.cal_zr()
        model.linear_fit()
        model.cal_gt_prob()

    print("Enter an input sentence :")
    input_text = input()

    n=len(input_text)
    token_input=custom_tokenizer(input_text)
    n=len(input_text)
    
    bituple=(token_input[-3:])
    most_dic={}
    for uni in model.unigram.keys():
        zzz=tuple(bituple[0][-2:]+list(uni))
        
        if(lm_type=='i'):
            most_dic[zzz]=model.probabilities.get(zzz,0)
        else:
            most_dic[zzz]=model.good_tuning_probailities.get(zzz,0)
    sorted_dict = dict(sorted(most_dic.items(), key=lambda item: item[1],reverse=True))
    v =0
    for key,value in sorted_dict.items():
        print(key[-1]," ",value)
        v+=1
        if(v==k):
            break
    
           

    



  
        
  

if __name__ == "__main__":
    main()






