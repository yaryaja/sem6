
# Embedding Generation and Downstream Task
### This zip folder contains code for generating word embeddings using two different methods, namely Skipgram and Singular Value Decomposition (SVD). Additionally, it includes scripts for conducting a downstream task, specifically a 4-class classification task, using the generated embeddings.

## Embedding Generation:
### Skipgram Embedding Generation:

The Skipgram model is implemented using PyTorch and trained on a given corpus to learn word embeddings.
To generate Skipgram embeddings:
Run the script NLP_A3_Final.ipynb in a Jupyter notebook environment.
The script preprocesses the text data, trains the Skipgram model, and saves the learned embeddings.
SVD Embedding Generation:

The SVD method is employed to generate word embeddings based on co-occurrence matrices.
To generate SVD embeddings:
Execute the NLP_A3_Final.ipynb in a Jupyter notebook environment.
The script computes co-occurrence matrices from the text data, applies SVD to reduce dimensionality, and saves the resulting embeddings.


## Downstream Task - 4-Class Classification:
Dataset Preparation:

The downstream task involves a 4-class classification problem.
The dataset is assumed to be in CSV format, where each row represents a text sample and its corresponding label.
Model Training:

The downstream task model, such as a neural network classifier(LSTM), is trained using either Skipgram or SVD embeddings as input features.
Scripts for training the classifier on the generated embeddings are provided.
Evaluation:

After training, the model's performance is evaluated using metrics such as accuracy, precision, recall, and F1-score.
Results are analyzed to compare the effectiveness of Skipgram and SVD embeddings for the downstream task.



Dependencies:
Python 3.x
PyTorch
NumPy
NLTK
Matplotlib
Pandas
Other required libraries (specified in each notebook)


Trained_models:
embeddings: 1- skipgram 2- svd
- https://drive.google.com/file/d/1V_Wf1NpMlqWODqGcXBt8ulsafDQD3ALo/view?usp=drive_link
- https://drive.google.com/file/d/1O2WOwsr9frFXoP5zbSdec4LCMwz32nqx/view?usp=drive_link

classification: 1- skipgram 2- svd
- https://drive.google.com/file/d/16EXEIqqIAGtEeP8ZTTp-2c2A_SAyo_mW/view?usp=drive_link
- https://drive.google.com/file/d/1O2WOwsr9frFXoP5zbSdec4LCMwz32nqx/view?usp=drive_link





