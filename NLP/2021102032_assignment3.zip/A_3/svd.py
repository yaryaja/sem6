import pandas as pd
import numpy as np
import csv
import re
from nltk.tokenize import word_tokenize
from sklearn.decomposition import TruncatedSVD
import torch
from google.colab import drive
import nltk

START_TOKEN = '<start>'
END_TOKEN = '<end>'

def preprocess_text(text):
    text = text.lower()
    text = text.strip()
    text = text.replace('.', ' <PERIOD> ')
    text = text.replace(',', ' <COMMA> ')
    text = text.replace('"', ' <QUOTATION_MARK> ')
    text = text.replace(';', ' <SEMICOLON> ')
    text = text.replace('!', ' <EXCLAMATION_MARK> ')
    text = text.replace('?', ' <QUESTION_MARK> ')
    text = text.replace('(', ' <LEFT_PAREN> ')
    text = text.replace(')', ' <RIGHT_PAREN> ')
    text = text.replace('--', ' <HYPHENS> ')
    text = text.replace(':', ' <COLON> ')
    text = re.sub(r'\b\d+\b', ' <NUM> ', text)
    words = text.split()
    return words

def compute_co_occurance_matrix(corpus, window_size=2):
    num_words = len(set(words))
    M = np.zeros((num_words, num_words))
    for doc in corpus:
        for idx, word in enumerate(doc):
            for i in range(idx + 1, min(idx + window_size + 1, len(doc))):
                M[word_to_index_svd[(preprocess_text(word))[0]], word_to_index_svd[(preprocess_text(doc[i]))[0]]] += 1
    M += M.T
    return M, word_to_index_svd

def reduce_to_k_dim(M, k=2):
    n_iters = 10
    M_reduced = None
    print("Running Truncated SVD over %i words..." % (M.shape[0]))
    svd = TruncatedSVD(n_components=k, algorithm='arpack')
    M_reduced = svd.fit_transform(M)
    var_explained = svd.explained_variance_ratio_.sum()
    print("Done.")
    return M_reduced, var_explained

def main():
    drive.mount('/content/drive')
    nltk.download('punkt')

    train_data = []
    with open('/content/drive/My Drive/NLP/A_3/train.csv', mode='r') as file:
        csvFile = csv.reader(file)
        train_data = [str(line[1]) for line in csvFile]
        train_data = train_data[1:]

    train_data = [[START_TOKEN] + word_tokenize(line) + [END_TOKEN] for line in train_data[:10000]]

    concatenated_data = ""
    for row in train_data:
        row_str = ','.join(row)
        concatenated_data += row_str

    words = preprocess_text(concatenated_data)

    print()
    print("Total words in text: {}".format(len(words)))
    print("Unique words: {}".format(len(set(words))))
    word_to_index_svd = {w: idx for idx, w in enumerate(set(words))}
    index_to_word_svd = {idx: w for idx, w in enumerate(set(words))}
    int_words = [word_to_index_svd[word] for word in words]

    M_test, word2ind_test = compute_co_occurance_matrix(train_data, window_size=2)
    k_test, var = reduce_to_k_dim(M_test, 128)

    # Convert to tensor
    svd_embeddings = torch.tensor(k_test)
    print(svd_embeddings.shape)

if __name__ == "__main__":
    main()
