from custom_tokenizer import custom_tokenizer

# N > 1
def n_gram(N, tokens):

    ngram_model = {}
    for token in tokens:
        token = ["start"]*(N-1) + token + ["end"]
        ngrams =[tuple(token[i:i+N]) for i in range(len(token)-N)]
        for gram in ngrams:
            if gram[:-1] not in ngram_model.keys():
                ngram_model[gram[:-1]] = {gram[-1:]:1}
            else:
                if gram[-1:] not in ngram_model[gram[:-1]].keys():
                    ngram_model[gram[:-1]][gram[-1:]] = 1
                else:
                    ngram_model[gram[:-1]][gram[-1:]] += 1
    return ngram_model

