import time
import random
import numpy as np
from collections import Counter
from nltk.tokenize import word_tokenize
import csv
import nltk
nltk.download('punkt')
import torch
from torch import nn
import torch.optim as optim
import re


word_to_index={}
index_to_word={}

def preprocess_text(text):
    text = text.lower()
    text = text.strip()
    text = text.replace('.', ' <PERIOD> ')
    text = text.replace(',', ' <COMMA> ')
    text = text.replace('"', ' <QUOTATION_MARK> ')
    text = text.replace(';', ' <SEMICOLON> ')
    text = text.replace('!', ' <EXCLAMATION_MARK> ')
    text = text.replace('?', ' <QUESTION_MARK> ')
    text = text.replace('(', ' <LEFT_PAREN> ')
    text = text.replace(')', ' <RIGHT_PAREN> ')
    text = text.replace('--', ' <HYPHENS> ')
    text = text.replace(':', ' <COLON> ')
    text = re.sub(r'\b\d+\b', ' <NUM> ', text)
    words = text.split()
    return words



def get_target(words,idx,window_size=5):
  R=np.random.randint(1,window_size+1)
  start=idx-R if (idx-R)>0 else 0
  stop =idx+R
  target_words=words[start:idx]+words[idx+1:stop+1]
  return list(target_words)

def get_batches(words, batch_size, window_size=5):
    n_batches = len(words) // batch_size

    words = words[:n_batches * batch_size]
    for idx in range(0, len(words), batch_size):
        x, y = [], []
        batch = words[idx:idx + batch_size]
        for j in range(len(batch)):
            batch_x = batch[j]
            batch_y = get_target(batch, j, window_size)
            y.extend(batch_y)
            x.extend([batch_x] * len(batch_y))
        yield x, y


def cosine_similarity(embedding, valid_size=16, valid_window=100, device='cpu'):
    embed_vectors = embedding.weight

    magnitudes = embed_vectors.pow(2).sum(dim=1).sqrt().unsqueeze(0)
    valid_examples = np.array(random.sample(range(valid_window), valid_size // 2))
    valid_examples = np.append(valid_examples, random.sample(range(1000, 1000 + valid_window), valid_size // 2))

    valid_examples = torch.LongTensor(valid_examples).to(device)
    valid_vectors = embedding(valid_examples)
    similarities = torch.mm(valid_vectors, embed_vectors.t()) / magnitudes

    return valid_examples, similarities


class skipgram(nn.Module):
    def __init__(self, n_vocab, n_embed, noise_dist=None):
        super().__init__()

        self.n_vocab = n_vocab
        self.n_embed = n_embed
        self.noise_dist = noise_dist

        self.in_embed = nn.Embedding(n_vocab, n_embed)
        self.out_embed = nn.Embedding(n_vocab, n_embed)

        self.in_embed.weight.data.uniform_(-1, 1)
        self.out_embed.weight.data.uniform_(-1, 1)

    def forward_input(self, input_words):
        input_vector = self.in_embed(input_words)
        return input_vector

    def forward_output(self, output_words):
        output_vector = self.out_embed(output_words)
        return output_vector

    def forward_noise(self, batch_size, n_samples):

        if self.noise_dist is None:
            noise_dist = torch.ones(self.n_vocab)
        else:
            noise_dist = self.noise_dist

        noise_words = torch.multinomial(noise_dist, batch_size * n_samples, replacement=True)

        device = "cuda" if model.out_embed.weight.is_cuda else "cpu"
        noise_words = noise_words.to(device)

        noise_vector = self.out_embed(noise_words).view(batch_size, n_samples, self.n_embed)
        return noise_vector

class NegativeSamplingLoss(nn.Module):
  def __init__(self):
    super().__init__()


  def forward(self,input_vectors,output_vectors,noise_vectors):
    batch_size,embed_size=input_vectors.shape

    input_vectors=input_vectors.view(batch_size,embed_size,1)

    output_vectors=output_vectors.view(batch_size,1,embed_size)

    out_loss=torch.bmm(output_vectors,input_vectors).sigmoid().log()
    out_loss=out_loss.squeeze()

    noise_loss=torch.bmm(noise_vectors.neg(),input_vectors).sigmoid().log()
    noise_loss=noise_loss.squeeze().sum(1)

    return -(out_loss+noise_loss).mean()
def main():
    device = 'cuda' if torch.cuda.is_available() else 'cpu'

    train_data = []
    with open('/content/drive/My Drive/NLP/A_3/train.csv', mode='r') as file:
        csvFile = csv.reader(file)
        train_data = [[(line[1])] for line in csvFile]
        train_data = train_data[1:]

    print(len(train_data))

    concatenated_data = ""
    for row in train_data:
        row_str = ','.join(row)
        concatenated_data += row_str

    words = preprocess_text(concatenated_data)
    print(words[:30])

    def get_target(words, idx, window_size=5):
        R = np.random.randint(1, window_size + 1)
        start = idx - R if (idx - R) > 0 else 0
        stop = idx + R
        target_words = words[start:idx] + words[idx + 1:stop + 1]
        return list(target_words)

    threshold = 1e-5
    word_counts = Counter(words)
    total_count = len(words)
    freqs = {word: count / total_count for word, count in word_counts.items()}
    p_drop = {word: 1 - np.sqrt(threshold / freqs[word]) for word in word_counts}
    train_words = [word for word in words if random.random() < (1 - p_drop[word])]
    print(train_words[:30])

    embedding_dim = 128
    model = skipgram(len(word_to_index), embedding_dim, noise_dist=noise_dist).to(device)

    criterion = NegativeSamplingLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.003)

    print_every = 1500
    steps = 0
    epochs = 5
    for e in range(epochs):

        Loss = None
        for input_words, target_words in get_batches(train_words, 512):
            steps += 1
            inputs, targets = torch.LongTensor(input_words), torch.LongTensor(target_words)
            inputs, targets = inputs.to(device), targets.to(device)

            input_vectors = model.forward_input(inputs)
            output_vectors = model.forward_output(targets)
            noise_vectors = model.forward_noise(inputs.shape[0], 5)

            loss = criterion(input_vectors, output_vectors, noise_vectors)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            Loss = loss.item()

        print("Epoch: {}/{}".format(e + 1, epochs))
        print("Loss: ", Loss)

    skipgram_embeddings = (model.in_embed.weight)
    print("Embedding shape:", skipgram_embeddings.shape)


if __name__ == "__main__":
    main()
