import pandas as pd
import numpy as np
import csv
import re
from nltk.tokenize import word_tokenize
from sklearn.decomposition import Truncatedskipgram
import torch
from google.colab import drive
import nltk
from torch import nn
# create Tensor datasets
from sklearn.preprocessing import LabelEncoder
from torch.utils.data import Dataset
from torch.utils.data import TensorDataset, DataLoader
from sklearn.model_selection import train_test_split


device="cuda" if torch.cuda.is_available()  else "cpu"


START_TOKEN = '<start>'
END_TOKEN = '<end>'
UNK_TOKEN='unknown'
word_to_index_skipgram={}
words=[]
def preprocess_text(text):
    text = text.lower()
    text = text.strip()
    text = text.replace('.', ' <PERIOD> ')
    text = text.replace(',', ' <COMMA> ')
    text = text.replace('"', ' <QUOTATION_MARK> ')
    text = text.replace(';', ' <SEMICOLON> ')
    text = text.replace('!', ' <EXCLAMATION_MARK> ')
    text = text.replace('?', ' <QUESTION_MARK> ')
    text = text.replace('(', ' <LEFT_PAREN> ')
    text = text.replace(')', ' <RIGHT_PAREN> ')
    text = text.replace('--', ' <HYPHENS> ')
    text = text.replace(':', ' <COLON> ')
    text = re.sub(r'\b\d+\b', ' <NUM> ', text)
    words = text.split()
    return words

def compute_co_occurance_matrix(corpus, window_size=2):
    num_words = len(set(words))
    M = np.zeros((num_words, num_words))
    for doc in corpus:
        for idx, word in enumerate(doc):
            for i in range(idx + 1, min(idx + window_size + 1, len(doc))):
                M[word_to_index_skipgram[(preprocess_text(word))[0]], word_to_index_skipgram[(preprocess_text(doc[i]))[0]]] += 1
    M += M.T
    return M, word_to_index_skipgram

def reduce_to_k_dim(M, k=2):
    n_iters = 10
    M_reduced = None
    print("Running Truncated skipgram over %i words..." % (M.shape[0]))
    skipgram = Truncatedskipgram(n_components=k, algorithm='arpack')
    M_reduced = skipgram.fit_transform(M)
    var_explained = skipgram.explained_variance_ratio_.sum()
    print("Done.")
    return M_reduced, var_explained


class LSTM_NEWS(nn.Module):
    def __init__(self,no_layers,vocab_size,hidden_dim,embedding_dim,drop_prob,computed_embedding):
        super(LSTM_NEWS,self).__init__()

        self.output_dim = 4
        self.hidden_dim = hidden_dim

        self.no_layers = no_layers
        self.vocab_size = vocab_size
        self.batch_size=50

        # embedding and LSTM layers
        self.embedding = nn.Embedding.from_pretrained(torch.FloatTensor(computed_embedding))
        # self.embedding = nn.Embedding(vocab_size, embedding_dim)

        #lstm
        self.lstm = nn.LSTM(input_size=embedding_dim,hidden_size=self.hidden_dim,
                           num_layers=no_layers, batch_first=True)


        # dropout layer
        self.dropout = nn.Dropout(0.3)

        # linear and sigmoid layer
        self.fc = nn.Linear(self.hidden_dim, 4)
        self.sig = nn.Sigmoid()


    def forward(self, x, hidden):
      batch_size = x.size(0)

      # embeddings and lstm_out
      embeds = self.embedding(x)  # shape: (batch_size, sequence_length, embedding_dim)
      lstm_out, hidden = self.lstm(embeds, hidden)

      # Select the last output of the sequence
      last_output = lstm_out[:, -1, :]  # shape: (batch_size, hidden_dim)

      # Apply dropout and fully connected layer
      out = self.dropout(last_output)
      out = self.fc(out)

      return out, hidden





    def init_hidden(self, batch_size):
        # print("hidden entered")
        ''' Initializes hidden state '''
        # Create two new tensors with sizes n_layers x batch_size x hidden_dim,
        # initialized to zero, for hidden state and cell state of LSTM
        h0 = torch.zeros((self.no_layers,batch_size,self.hidden_dim)).to(device)
        c0 = torch.zeros((self.no_layers,batch_size,self.hidden_dim)).to(device)
        hidden = (h0,c0)
        return hidden
    
    def padding_(sentences, seq_len):
        features = np.zeros((len(sentences), seq_len),dtype=int)
        for ii, review in enumerate(sentences):
            if len(review) != 0:
                features[ii, -len(review):] = np.array(review)[:seq_len]
        return features

def main():
    drive.mount('/content/drive')
    nltk.download('punkt')

    train_data = []
    with open('/content/drive/My Drive/NLP/A_3/train.csv', mode='r') as file:
        csvFile = csv.reader(file)
        train_data = [str(line[1]) for line in csvFile]
        train_data = train_data[1:]

    train_data = [[START_TOKEN] + word_tokenize(line) + [END_TOKEN] for line in train_data[:10000]]

    concatenated_data = ""
    for row in train_data:
        row_str = ','.join(row)
        concatenated_data += row_str

    words = preprocess_text(concatenated_data)

    print()
    print("Total words in text: {}".format(len(words)))
    print("Unique words: {}".format(len(set(words))))
    word_to_index_skipgram = {w: idx for idx, w in enumerate(set(words))}
    index_to_word_skipgram = {idx: w for idx, w in enumerate(set(words))}
    int_words = [word_to_index_skipgram[word] for word in words]

    M_test, word2ind_test = compute_co_occurance_matrix(train_data, window_size=2)
    k_test, var = reduce_to_k_dim(M_test, 128)

    # Convert to tensor
    skipgram_embeddings = torch.tensor(k_test)
    print(skipgram_embeddings.shape)



    ## classification
    # Open the CSV file
    from nltk import word_tokenize
    with open('/content/drive/My Drive/NLP/A_3/train.csv', 'r') as file:
        csvFile = csv.reader(file)
        data = list(csvFile)

        train_labels = [line[0] for line in data[1:]]  # Skip the header
        train_corpus = [word_tokenize(line[1]) for line in data[1:]]
    print("train data")
    value_counts = pd.Series(train_labels).value_counts()
    print(value_counts)

    with open('/content/drive/My Drive/NLP/A_3/test.csv', mode='r') as file:
        csvFile = csv.reader(file)
        data=list(csvFile)

        test_labels=  [line[0] for line in data[1:]]
        test_corpus= [word_tokenize(line[1]) for line in data[1:]]

    print("test data")
    value_counts = pd.Series(test_labels).value_counts()
    print(value_counts)
    print()
    
    # Open the CSV file
    from nltk import word_tokenize
    with open('/content/drive/My Drive/NLP/A_3/train.csv', 'r') as file:
        csvFile = csv.reader(file)
        data = list(csvFile)

        train_labels = [line[0] for line in data[1:]]  # Skip the header
        train_corpus = [word_tokenize(line[1]) for line in data[1:]]
    print("train data")
    value_counts = pd.Series(train_labels).value_counts()
    print(value_counts)

    with open('/content/drive/My Drive/NLP/A_3/test.csv', mode='r') as file:
        csvFile = csv.reader(file)
        data=list(csvFile)

        test_labels=  [line[0] for line in data[1:]]
        test_corpus= [word_tokenize(line[1]) for line in data[1:]]

    print("test data")
    value_counts = pd.Series(test_labels).value_counts()
    print(value_counts)
    print()
    
    train_x=[]
    test_x=[]

    from nltk import word_tokenize
    for row in train_corpus:

            row_str=word_tokenize(row_str)
            row_str = ' '.join(row)
            words=preprocess_text(row_str)
            words = [word_to_index_skipgram.get(word, word_to_index_skipgram[UNK_TOKEN]) for word in words]

            train_x.append(words)

    for row in test_corpus:
            row_str = ' '.join(row)
            words=preprocess_text(row_str)
            words = [word_to_index_skipgram.get(word, word_to_index_skipgram[UNK_TOKEN]) for word in words]

    y_train = np.array([0 if label == '1' else (1 if label == '2' else (2 if label == '3' else 3)) for label in train_labels])
    y_test= np.array([0 if label == '1' else (1 if label == '2' else (2 if label == '3' else 3)) for label in test_labels])

    x_train_pad =padding_(train_x,100)
    x_test_pad=padding_(test_x,100)
    train_data = TensorDataset(torch.from_numpy(x_train_pad), torch.from_numpy(y_train))
    valid_data = TensorDataset(torch.from_numpy(x_test_pad), torch.from_numpy(y_test))

    # dataloaders
    batch_size = 50

    # make sure to SHUFFLE your data
    train_loader = DataLoader(train_data, shuffle=True, batch_size=batch_size)
    valid_loader = DataLoader(valid_data, shuffle=True, batch_size=batch_size)


    def add_new_word(new_word, new_vector, new_index, embedding_matrix, word_to_index):
        print(type(new_vector))

        embedding_matrix = np.insert(embedding_matrix, [new_index], [new_vector], axis=0)
        word_to_ind = {word: (index + 1) if index >= new_index else index for word, index
                    in word_to_index.items()}
        word_to_index[new_word] = new_index
        return embedding_matrix, word_to_index

    UNK_INDEX = 0
    
    UNK_Vector = skipgram_embeddings.mean(0)


    # Assuming skipgram_embeddings and word_to_index are defined earlier
    skipgram_embeddings, word_to_index_skipgram = add_new_word(UNK_TOKEN, UNK_Vector, UNK_INDEX, skipgram_embeddings, word_to_index_skipgram)

    no_layers = 2
    vocab_size =len( word_to_index_skipgram)+ 1 #extra 1 for padding
    embedding_dim = 128
    output_dim = 4
    hidden_dim = 256


    model = LSTM_NEWS(no_layers,vocab_size,hidden_dim,embedding_dim,0.5,skipgram_embeddings)

    #moving to gpu
    model.to(device)

    print(model)
    
    
    
        
    clip = 5
    epochs = 5
    valid_loss_min = np.Inf
    # train for some number of epochs
    epoch_tr_loss,epoch_vl_loss = [],[]
    epoch_tr_acc,epoch_vl_acc = [],[]

    for epoch in range(epochs):
        train_losses = []
        train_acc_no = 0.0
        model.train()
        # initialize hidden state
        # print("hidden started")
        h = model.init_hidden(batch_size)
        # print("train started")
        # print(len(train_loader))
        indddd=0
        for inputs, labels in train_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            # Creating new variables for the hidden state, otherwise
            # we'd backprop through the entire training history
            h = tuple([each.data for each in h])

            model.zero_grad()
            output,h = model(inputs,h)
            # Move labels tensor to the same device as the output tensor
            labels = labels.type(torch.LongTensor)
            # print(output)
            labels = labels.to(output.device)
            # print(labels)
            # calculate the loss and perform backprop
            loss_fn = nn.CrossEntropyLoss()
            loss = loss_fn(output, labels)

            # loss = nn.CrossEntropyLoss(output, labels)
            loss.backward()
            train_losses.append(loss.item())
            # calculating accuracy
            accuracy = acc(output,labels)
            train_acc_no += accuracy
            #`clip_grad_norm` helps prevent the exploding gradient problem in RNNs / LSTMs.
            nn.utils.clip_grad_norm_(model.parameters(), clip)
            optimizer.step()



            val_h = model.init_hidden(batch_size)
            val_losses = []
            val_acc_no = 0.0
            model.eval()
            for inputs, labels in valid_loader:
                    val_h = tuple([each.data for each in val_h])

                    inputs, labels = inputs.to(device), labels.to(device)
                    # print(labels)
                    loss_fn = nn.CrossEntropyLoss()
                    output, val_h = model(inputs, val_h)
                    # print(output)
                    val_loss = loss_fn(output, labels)

                    val_losses.append(val_loss.item())

                    accuracy = acc(output,labels)
                    val_acc_no += accuracy

            epoch_train_loss = np.mean(train_losses)
            epoch_val_loss = np.mean(val_losses)
            epoch_train_acc = train_acc_no/len(train_loader)
            epoch_val_acc = val_acc_no/len(valid_loader)
            epoch_tr_loss.append(epoch_train_loss)
            epoch_vl_loss.append(epoch_val_loss)
            epoch_tr_acc.append(epoch_train_acc)
            epoch_vl_acc.append(epoch_val_acc)
            print(f'Epoch {epoch+1}')
            print(f'train_loss : {epoch_train_loss} val_loss : {epoch_val_loss}')
            print(f'train_accuracy : {epoch_train_acc*100/50} val_accuracy : {epoch_val_acc*100/50}')
            if epoch_val_loss <= valid_loss_min:
                directory = 'content/drive/My_Drive/NLP/A_3/skipgram_classification.pt'
                os.makedirs(os.path.dirname(directory), exist_ok=True)
                torch.save(model.state_dict(), directory)
                # print('Validation loss decreased ({6f} --> {6f}).  Saving model ...'.format(valid_loss_min,epoch_val_loss))
                valid_loss_min = epoch_val_loss
            print(25*'==')




if __name__ == "__main__":
    main()
